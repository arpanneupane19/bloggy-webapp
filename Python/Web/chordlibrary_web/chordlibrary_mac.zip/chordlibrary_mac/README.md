Control+Click on the ChordLibrary file that has a snake icon.
If it doesn't allow you to view the file, cancel it and try again.
It should open. 
You can use this to learn guitar chords.